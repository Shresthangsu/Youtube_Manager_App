def load_data():
#     pass